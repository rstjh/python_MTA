def IsYearLeap(year):
    if ((year % 4 is 0) and (year % 100 is not 0)) or (year % 400 is 0):
        return True
    else: return False


def DaysInMonth(year,month):
    if year == 0 or month == 0 or month > 12: return None
    daysinmonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if IsYearLeap(year):
       daysinmonths[1] = 29
    return daysinmonths[month-1]


testyears = [1900, 2000, 2016, 1987]
testmonths = [ 2, 2, 1, 11]
testresults = [28, 29, 31, 30]

for i in range(len(testyears)):
	yr = testyears[i]
	mo = testmonths[i]
	print(yr,mo,"->",end="")
	result = DaysInMonth(yr,mo)
	if result == testresults[i]:
		print("OK")
	else:
		print("Failed")

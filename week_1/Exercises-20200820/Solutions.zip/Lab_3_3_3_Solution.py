def IsYearLeap(year):
    """Function to check if a given year is a leap year"""
    if ((year % 4 is 0) and (year % 100 is not 0)) or (year % 400 is 0):
        return True
    else:
        return False

def DaysInMonth(year,month):
    """Function to check how many days are in a given month in a given year"""
    daysinallmonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if IsYearLeap(year) and month == 2:
        return 29 # return 29 days for the month of feb in a leap year
    else:
        return daysinallmonths[month-1] # return days for the month from the list

def DayOfYear(year,month,day):
    """Function to count the number of days elapsed in the year to date"""
    totaldays = day
    if month != 1: # if not January, add the number of days in the preceding months to day to calculate DayOfYear
        for i in range(1, month): # loop to read the 
            totaldays += DaysInMonth(year, i)
            print(year, i, totaldays)
        return totaldays

print(DayOfYear(2000,3,4))
print(DayOfYear(2001,3,4))
print(DayOfYear(2001,2,5))
print(DayOfYear(2016,8,5))
print(DayOfYear(2000,12,31))
print(DayOfYear(2001,12,31))
def IsYearLeap(year):
    """Function to check if a given year is a leap year"""
    if ((year % 4 is 0) and (year % 100 is not 0)) or (year % 400 is 0):
        return True
    else: return False
    #end of function

""" The following lists specifies input test data and the corresponding expected results"""
testdata = [1900, 2000, 2016, 1987]
testresults = [False, True, True, False]

""" The following for loop invokes the IsYearLeap() function on each YEAR provided in testdata[] list
    the result returned from IsYearLeap() is then compared with the corresponding entry in testresults[] 
    If the value returned from the function matches the corresponding result then the 'OK' message is displayed
    beside the YEAR tested to indicate this test case has PASSED - (ie our code appears to be correct)
    otherwise 'Failed' message is displayed beside the YEAR tested to indicate teh test case has FAILED 
"""

for i in range(len(testdata)):
    yr = testdata[i]
    print(yr,"->",end="")
    result = IsYearLeap(yr)
    if result == testresults[i]:
        print("OK")
    else:
        print("Failed")

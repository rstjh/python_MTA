def IsPrime(num):
    """function to identify prime numbers"""
    if num > 1:

        for i in range (2, num):
            if (num % i) == 0 and num != i:
                #print(num, "is not a prime number") #debug
                return False
        else:
            #print(num, "is a prime number") #debug
            return True

for i in range(1,20):
    if IsPrime(i + 1):
        print(i+1,end=" ")
print()
